<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class naics_risk extends Model
{
    //
    protected $table ='naics_risk';
    public $timestamps = false;
}
