<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class analysis extends Model
{
    //
    protected $table ='analysis';
    public $timestamps = false;
}
