<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class umbrella_slab extends Model
{
    //
    protected $table ='umbrella_slab';
    public $timestamps = false;
}
