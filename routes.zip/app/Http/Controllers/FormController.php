<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\analysis;
use DB;

class FormController extends Controller
{
    //
    function insurance(Request $req){
        $profession = $req->input('profession');
        $revenue = $req->input('revenue');
        $employees = $req->input('employees');
        $building = $req->input('building');
        $building_value = $req->input('building_value');
        if($profession != '' && $revenue != '' && $employees != ''){

            $user_ip_address =  $user_ip_address=$req->ip();

            $dataAnalysis = DB::table('analysis')->Where('ip', '=', $user_ip_address)->get();
            // echo "<pre>";
            //     var_dump($dataAnalysis);
            // echo "</pre>";

            $wordCount = count($dataAnalysis);
            if($wordCount >= 3){
                //return redirect('/home/exceeded');  
            }
            
            $analysis =new analysis;
                $analysis -> ip = $user_ip_address;
                $analysis -> profession = $profession;
                $analysis -> revenue = $revenue;
                $analysis -> no_of_employees = $employees;
                $analysis ->save();
            }    
            
            return redirect('/home/'.$profession.'/'.''.$revenue.'/'.$employees.'/'.$building.'/'.$building_value);
       


    }
}
