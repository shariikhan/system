<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\naics_risk;
use App\umbrella_slab;
use DB;

class RootController extends Controller
{
    /**
     * Create a new controller instance.
     *
     */
    public function __construct()
    {
        //return view('admin.profile', compact('id'));
    }

    public function index($profession = null, $revenue = null, $employees = null, $building = null, $building_value = null)
    {

       // $naics_risk_date = naics_risk::all();
       $calLiability = naics_risk::where('naics_code', '=', $profession)->get();

       $calUmbrella = umbrella_slab::where('id', '!=' , "")->get(); 

       $gotUmbrella = umbrella_slab::where('id', '=', $revenue)->get();

       $naics_risk_date = naics_risk::whereNotNull('id')->orderBy('naics_title', 'ASC')->get();

        return view('welcome.dashboard', compact('profession', 'revenue', 'employees', 'building', 'building_value', 'naics_risk_date', 'calLiability', 'calUmbrella', 'gotUmbrella'));   

    }

    
}
