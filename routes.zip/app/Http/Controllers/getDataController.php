<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\naics_risk;
use App\umbrella_slab;
use DB;


class getDataController extends Controller
{
    //
    function insurance(Request $req){

       $profession = $req->input('profession_v');
       $revenue = $req->input('revenue_v');
       $property = $req->input('property_v');
       $gotUmbrella = umbrella_slab::where('id', '=', $revenue)->get();

       $calLiability = naics_risk::where('naics_code', '=', $profession)->get();

       return view('getData', compact('profession','revenue', 'gotUmbrella', 'calLiability', 'property'));
       
    }
}
