<div class="container" data-aos="fade-up" id="insurance_can" >

        <div class="row" >

        

<script src="//code.jquery.com/jquery-1.9.1.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>

        <div class="col-lg-12"  style="text-align: center; padding-bottom:50px;" >
            <h2 class="page-header" >Insurance Protection </h2>
            <canvas  id="insurance"></canvas> 
        </div>
        <div class="col-lg-4" style="text-align: center;" >
            <h2 class="page-header" >Major Risk Exposures</h2>
            <canvas  id="risk"></canvas> 
        </div> 

        
 <?php 
 foreach($calLiability as $calLiabilitys){
     
    $Liability_get = preg_replace( '/[^0-9]/', '', $calLiabilitys['liability'] );
 }
 
 $gotUmbrellassss = '';
 foreach($gotUmbrella as $gotUmbrellas){
     
    $gotUmbrellassss =  $gotUmbrellas['surplus'];
 }
 
 ?>


 

<?php 

//$productname =  array("Liability", "Umbrella", "Property", "Inland Maine", "Workers Compensation", "Employment Practices", "Cyber", "Business Auto", "Professional Liability", "Disability", "Key Person, Buy Sell", "Potential Coverage Gaps");
//$points = array("1000000", "2000000", "2500000", "77", "99", "150", "55", "55", "32", "88", "68", "111"); 

$productname =  array("Liability", "Umbrella", "Property", "Inland Maine");
$points = array($Liability_get, $gotUmbrellassss, $property, ""); 


$riskname =  array("Liability", "Umbrella", "Property");
$riskpoints = array($Liability_get, $gotUmbrellassss, $property); 

?>     


<script type="text/javascript">




        $(document).ready(function () {
          $('html, body').animate({
              //scrollTop: $('#insurance_can').offset().top
          }, 'slow');
          });
        

      var ctx = document.getElementById("insurance").getContext('2d');
                var myChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels:<?php echo json_encode($productname); ?>,
                        datasets: [{
                            backgroundColor: [
                               "#5969ff",
                                "#ff407b",
                                "#25d5f2",
                                "#ffc750",
                                "#2ec551",
                                "#7040fa",
                                "#ff004e",
                                "#ffc750",
                                "#2ec551",
                                "#ff407b",
                                "#25d5f2",
                                "#7040fa"

                            ],
                            data:<?php echo json_encode($points); ?>,
                        }]
                    },
                    options: {
                           legend: {
                        display: false,
                        position: 'bottom',
 
                        labels: {
                            fontColor: '#71748d',
                            fontFamily: 'Circular Std Book',
                            fontSize: 14,
                        }
                    },
 
 
                }
                });


                var risk = document.getElementById("risk").getContext('2d');
                var myChart = new Chart(risk, {
                    type: 'polarArea',
                    data: {
                        labels:<?php echo json_encode($riskname); ?>,
                        datasets: [{
                            backgroundColor: [
                               "#5969ff",
                                "#ff407b",
                                "#25d5f2",
                                "#ffc750",
                                "#2ec551",
                                "#7040fa",
                                "#ff004e",
                                "#ffc750",
                                "#2ec551",
                                "#ff407b",
                                "#25d5f2",
                                "#7040fa"

                            ],
                            data:<?php echo json_encode($riskpoints); ?>,
                        }]
                    },
                    options: {
                           legend: {
                        display: true,
                        position: 'bottom',
 
                        labels: {
                            fontColor: '#71748d',
                            fontFamily: 'Circular Std Book',
                            fontSize: 14,
                        }
                    },
 
 
                }
                });

                
    </script>     
      

        </div>
      </div>

 