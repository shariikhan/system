
@extends('welcome.master')

@section('content');
  
  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex justify-content-center align-items-center" >
    <div class="container position-relative" data-aos="zoom-in" data-aos-delay="100" >
      <h1 >When you think insurance, Think Preferred</h1>
      <span id="get_quote"></span>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about" >
      <div class="container" data-aos="fade-up" >

        <div class="row" >
        @if($profession =='exceeded')
        <script src="//code.jquery.com/jquery-1.9.1.js"></script> 
        <script>
        $(document).ready(function () {
          $('html, body').animate({
              scrollTop: $('#get_quote').offset().top
          }, 'slow');
          });
        </script>
        <div class="alert alert-warning blink_me" >
        <strong>Alert:</strong> You have axceeded free limit, please get <a href="{{ asset('/register') }}" class="alert-link">register</a> first. for more analysis.
        </div>
        @endif
          <div class="col-lg-12 pt-4 pt-lg-0 order-2 order-lg-1 content contact" id="contact">

                <form action="{{ asset('FormController') }}"  method="post" role="form" class="php-email-form-b" id="canvas">
                @csrf
                    <div class="row">
                      <div class="col-md-6 form-group">

                        <select class="form-control input-group input-group-sm select2"  name="profession" id="profession" style="width: 100%;" onchange="GetChart();">
                          <option value="">Select Profession</option>
                          @foreach($naics_risk_date as $naics_datas)
                                  <option value="<?php echo $naics_datas['naics_code']; ?>" @if($naics_datas['naics_code'] == $profession) selected @endif ><?php echo str_replace(" ","&nbsp;",$naics_datas['naics_title']); ?></option>
                          @endforeach
                        </select>
                      </div>

                      <div class="col-md-6 form-group mt-3 mt-md-0 revenue_Div">
                      <select class="form-control input-group input-group-sm select2 " id="revenue"  name="revenue" style="width: 100%;" onchange="GetChart();">
                          <option value="">Select Gross Revenue</option>
                          @foreach($calUmbrella as $calUmbrellas)
                          <?php $low_rev = str_replace(".01","",$calUmbrellas['low_rev']) / 1000000; $high_rev = $calUmbrellas['high_rev'] / 1000000;  ?>  
                          <option value="<?php echo $calUmbrellas['id'];?>" @if($revenue == $calUmbrellas['id']) selected @endif>$<?php echo $low_rev.'M' ;?>-$<?php echo $high_rev.'M';?></option>
                          @endforeach
                        </select> 
                      </div>


                      <div class="col-md-6 form-group mt-3 mt-md-0 employee_Div">
                      <select class="form-control input-group input-group-sm select2" name="employees" style="width: 100%;" onchange="GetChart();">
                          <option value="">Select Number of Employees</option>
                          <option value="1-10" @if($employees =='1-10') selected @endif>1 to 10</option>
                          <option value="10-20" @if($employees =='10-20') selected @endif>10 to 20</option>
                          <option value="20-50" @if($employees =='20-50') selected @endif>20 to 50</option>
                          <option value="50-100" @if($employees =='50-100') selected @endif>50 to 100</option>
                          <option value="101-150" @if($employees =='101-150') selected @endif>101 to 150</option>
                          <option value="151-200" @if($employees =='151-200') selected @endif>151 to 200</option>
                          <option value="200-250" @if($employees =='200-250') selected @endif>200 to 250</option>
                        </select> 
                      </div>
                     


                      <div class="col-md-6 form-group mt-3 mt-md-0 employee_Div">
                      <select class="form-control input-group input-group-sm select2" name="building" id="building" style="width: 100%;" onchange="GetChart();">
                          <option value="">Do You Own Your Building?</option>
                          <option value="y" @if($building =='y') selected @endif>Yes</option>
                          <option value="n" @if($building =='n') selected @endif>No</option>
                        </select> 
                      </div>


                      <div class="col-md-6 form-group mt-3 mt-md-0 property_Value">
                        <input type="number " name="building_value" id="property_Value" onkeyup="GetChart();" value="" class="form-control" placeholder="What is the value of the building?" required="">
                      </div>
                      
                      
                      
                    </div>



                   
                    <div class="my-3" >
                      <div class="loading">Loading</div>
                      <div class="error-message"></div>
                      <div class="sent-message">Your message has been sent. Thank you!</div>
                     
                    </div>
                    
                  </form>

          </div>
        </div>
        
          
      </div>
    </section><!-- End About Section -->

<script src="//code.jquery.com/jquery-1.9.1.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>
<script>
 $(".revenue_Div").hide();
 $(".employee_Div").hide();
 $(".property_Value").hide();
 
function GetChart(){
  var profession = document.getElementById("profession");
  var profession_value = profession.value;
  var revenue = document.getElementById("revenue");
  var revenue_value = revenue.value;
  var building = document.getElementById("building");
  var building_value = building.value;
  var property_Value = document.getElementById("property_Value");
  var property_ValueF = property_Value.value;

  if(profession_value == ''){
    alert("Please Select Profession First.");
  }else{
    $(".revenue_Div").show("slow");
  }

  if(revenue_value != ''){
    $(".employee_Div").show("slow");
  }

  if(building_value == 'y'){
    $(".property_Value").show("slow");
  }

  
  //alert(profession_value);  
  // AJAX request
  $.ajax({
    headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },url: 'http://127.0.0.1:8000/getData',
   type: 'post',
   data: {profession_v: profession_value, revenue_v: revenue_value, property_v: property_ValueF},
   success: function(response){ 
     // Add response in Modal body
     $('.loadcharts').html(response);

   }
 });
 
}



</script>

    <section id="about" class="about loadcharts" >

    </section>

    

    

   

  

  </main><!-- End #main -->
  @endsection